package version

var BuildVersion = "dev"
