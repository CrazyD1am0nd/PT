package common

const (
	// MetricsNamespace is the namespace for all metrics.
	MetricsNamespace = "trufflehog"
	// MetricsSubsystem is the subsystem for all metrics.
	MetricsSubsystem = "scanner"
)
